#!/usr/bin/env python3
"""
Draw premium pixel art hat sprites for Mini Mayhem.
Each is exactly 66x60 px RGBA PNG.
Style: chunky pixel art, bold colors, dark outlines (color #1a1a1a or black).
"""

from PIL import Image, ImageDraw
import os

OUT_DIR = "/home/dusty/arty/deploy/assets/cosmetics"
W, H = 66, 60

# Color palette
BLACK  = (10, 10, 10, 255)
TRANS  = (0, 0, 0, 0)

def new_img():
    img = Image.new("RGBA", (W, H), TRANS)
    return img

def px(img, x, y, color):
    if 0 <= x < W and 0 <= y < H:
        img.putpixel((x, y), color)

def hline(img, x0, x1, y, color):
    for x in range(x0, x1+1):
        px(img, x, y, color)

def vline(img, x, y0, y1, color):
    for y in range(y0, y1+1):
        px(img, x, y, color)

def rect(img, x0, y0, x1, y1, color):
    for y in range(y0, y1+1):
        for x in range(x0, x1+1):
            px(img, x, y, color)

def outline_rect(img, x0, y0, x1, y1, fill, outline):
    rect(img, x0, y0, x1, y1, fill)
    hline(img, x0, x1, y0, outline)
    hline(img, x0, x1, y1, outline)
    vline(img, x0, y0, y1, outline)
    vline(img, x1, y0, y1, outline)

def flood_outline(img, color):
    """Add 1px dark outline around all opaque pixels."""
    data = img.load()
    to_set = []
    for y in range(H):
        for x in range(W):
            if data[x, y][3] > 0 and data[x, y] != color:
                for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
                    nx, ny = x+dx, y+dy
                    if 0 <= nx < W and 0 <= ny < H and data[nx, ny][3] == 0:
                        to_set.append((nx, ny))
    for x, y in to_set:
        px(img, x, y, color)


# ─────────────────────────────────────────────────────────────
# HAT 38 — Cosmic Crown
# Tall regal crown, deep purple/blue with glowing star gems, gold trim, shimmer dots
# ─────────────────────────────────────────────────────────────
def draw_hat_38():
    img = new_img()

    # Colors
    GOLD_DARK  = (160, 110, 10, 255)
    GOLD_MID   = (210, 160, 30, 255)
    GOLD_LIGHT = (255, 210, 70, 255)
    PURP_DARK  = (30, 15, 65, 255)
    PURP_MID   = (70, 35, 140, 255)
    PURP_LIGHT = (110, 65, 200, 255)
    BLUE_GEM   = (100, 160, 255, 255)
    STAR_GLOW  = (200, 220, 255, 255)
    WHITE_STAR = (240, 240, 255, 255)
    SHIMMER    = (180, 200, 255, 200)

    cx = 33  # center x

    # ── Base band (gold) ──────────────────────────────────────
    # Band: y=46..51, x=12..54
    for y in range(47, 52):
        for x in range(12, 55):
            if y == 47 or y == 51:
                px(img, x, y, GOLD_DARK)
            else:
                px(img, x, y, GOLD_MID)
    # Band highlight top edge
    hline(img, 13, 53, 48, GOLD_LIGHT)
    # Band outline
    hline(img, 11, 55, 47, BLACK)
    hline(img, 11, 55, 51, BLACK)
    vline(img, 11, 47, 51, BLACK)
    vline(img, 55, 47, 51, BLACK)

    # Diamond pattern on band (dark purple lozenges)
    for i, bx in enumerate([19, 27, 33, 39, 47]):
        by = 49
        px(img, bx,   by-1, PURP_DARK)
        px(img, bx-1, by,   PURP_DARK)
        px(img, bx+1, by,   PURP_DARK)
        px(img, bx,   by+1, PURP_DARK)
        px(img, bx,   by,   PURP_LIGHT)

    # ── Crown body (purple) ───────────────────────────────────
    # Main body fills y=16..46 roughly trapezoid
    for y in range(17, 47):
        half = 17 + (y - 17) * 3 // 30  # slight taper inward as we go up (inverted)
        # Actually crown widens at base
        base_half = 18
        top_half  = 14
        # interpolate: y=17 is top of body, y=46 is bottom
        t = (y - 17) / 29.0
        half_w = int(top_half + t * (base_half - top_half))
        for x in range(cx - half_w, cx + half_w + 1):
            shade = PURP_MID if (x + y) % 3 != 0 else PURP_DARK
            px(img, x, y, shade)

    # Vertical gold ribs on crown
    for rx in [cx - 10, cx, cx + 10]:
        for y in range(18, 47):
            px(img, rx, y, GOLD_DARK)
        # highlight
        for y in range(18, 47):
            px(img, rx + 1, y, GOLD_LIGHT)

    # ── Crown points (5 points) ──────────────────────────────
    # Center point: tallest
    # Pattern: points at x = 15, 22, 33, 44, 51 (tips)
    # Heights (tip y): center=4, sides=10, outer=16
    tips = [(15, 16), (22, 9), (33, 3), (44, 9), (51, 16)]

    for (tx, ty) in tips:
        # Draw triangular point from tip down to crown body top (~y=16)
        base_y = 17
        for y in range(ty, base_y + 1):
            half_w = max(0, (y - ty) * 3 // (base_y - ty + 1) + 0)
            for x in range(tx - half_w, tx + half_w + 1):
                px(img, x, y, PURP_MID)
            # Outline sides
            if y > ty:
                px(img, tx - half_w, y, BLACK)
                px(img, tx + half_w, y, BLACK)
        px(img, tx, ty, BLACK)  # tip pixel

    # Gold trim at top of body
    for (tx, ty) in tips:
        base_y = 17
        # gold dot at base of each point
        px(img, tx, base_y, GOLD_LIGHT)
        px(img, tx-1, base_y, GOLD_MID)
        px(img, tx+1, base_y, GOLD_MID)

    # ── Star gems on points ──────────────────────────────────
    def draw_star_gem(img, cx, cy, inner_col, outer_col):
        # 5px star: center + 4 cardinal + 4 diagonal lighter
        px(img, cx,   cy,   WHITE_STAR)
        px(img, cx-1, cy,   inner_col)
        px(img, cx+1, cy,   inner_col)
        px(img, cx,   cy-1, inner_col)
        px(img, cx,   cy+1, inner_col)
        px(img, cx-1, cy-1, outer_col)
        px(img, cx+1, cy-1, outer_col)
        px(img, cx-1, cy+1, outer_col)
        px(img, cx+1, cy+1, outer_col)

    gem_colors = [
        (BLUE_GEM, STAR_GLOW),   # outer left
        (GOLD_LIGHT, GOLD_MID),  # inner left
        (STAR_GLOW, BLUE_GEM),   # center (biggest)
        (GOLD_LIGHT, GOLD_MID),  # inner right
        (BLUE_GEM, STAR_GLOW),   # outer right
    ]
    gem_offsets = [(0, 4), (0, 3), (0, 3), (0, 3), (0, 4)]  # y offset from tip
    for i, (tx, ty) in enumerate(tips):
        gy = ty + gem_offsets[i][1]
        draw_star_gem(img, tx, gy, gem_colors[i][0], gem_colors[i][1])

    # ── Shimmer dots (magical sparkles) ─────────────────────
    sparkles = [
        (18, 25), (28, 21), (38, 28), (48, 22), (23, 35),
        (43, 38), (15, 40), (51, 40), (33, 30),
    ]
    for sx, sy in sparkles:
        px(img, sx, sy, SHIMMER)
        px(img, sx+1, sy, WHITE_STAR)

    # ── Outline crown body ───────────────────────────────────
    flood_outline(img, BLACK)

    img.save(os.path.join(OUT_DIR, "hat_38.png"))
    print("Saved hat_38.png")


# ─────────────────────────────────────────────────────────────
# HAT 39 — Phoenix Crest
# Flaming bird plume rising from gold headband. Orange/red/gold, dramatic upward sweep.
# ─────────────────────────────────────────────────────────────
def draw_hat_39():
    img = new_img()

    GOLD_BAND_D = (150, 100, 5, 255)
    GOLD_BAND_M = (210, 155, 25, 255)
    GOLD_BAND_L = (255, 205, 65, 255)
    RED_DARK    = (160, 30, 5, 255)
    RED_MID     = (220, 55, 10, 255)
    ORANGE_MID  = (240, 110, 20, 255)
    ORANGE_LITE = (255, 160, 40, 255)
    YELLOW_HOT  = (255, 215, 60, 255)
    WHITE_HOT   = (255, 245, 180, 255)
    GOLD_FEATHER= (220, 170, 30, 255)

    cx = 33

    # ── Headband ─────────────────────────────────────────────
    # y=48..53, x=10..56
    for y in range(48, 54):
        for x in range(10, 57):
            if y in (48, 53):
                px(img, x, y, GOLD_BAND_D)
            elif y == 49:
                px(img, x, y, GOLD_BAND_L)
            else:
                px(img, x, y, GOLD_BAND_M)
    # Outline
    hline(img, 9, 57, 48, BLACK)
    hline(img, 9, 57, 53, BLACK)
    vline(img, 9, 48, 53, BLACK)
    vline(img, 57, 48, 53, BLACK)

    # Gold rivets on band
    for rx in [14, 22, 33, 44, 52]:
        px(img, rx, 50, GOLD_BAND_L)
        px(img, rx, 51, GOLD_BAND_D)

    # ── Main flame plume — sweeps right and upward ────────────
    # We'll draw layered flame shapes as filled polygons via pixel rows

    def flame_col(t):
        """t=0 (base) to 1 (tip): dark red -> orange -> yellow -> white"""
        if t < 0.3:
            r = int(160 + (220 - 160) * t / 0.3)
            g = int(30 + (55 - 30) * t / 0.3)
            b = 5
        elif t < 0.6:
            r = int(220 + (255 - 220) * (t - 0.3) / 0.3)
            g = int(55 + (160 - 55) * (t - 0.3) / 0.3)
            b = 10
        elif t < 0.85:
            r = 255
            g = int(160 + (215 - 160) * (t - 0.6) / 0.25)
            b = int(40 + (60 - 40) * (t - 0.6) / 0.25)
        else:
            r = 255
            g = int(215 + (245 - 215) * (t - 0.85) / 0.15)
            b = int(60 + (180 - 60) * (t - 0.85) / 0.15)
        return (r, g, b, 255)

    # Central tall flame: from y=47 up to y=2, x centered around cx with gentle rightward lean
    # Define flame half-width at each y
    flame_bottom = 47
    flame_top    = 3
    for y in range(flame_top, flame_bottom + 1):
        t = (flame_bottom - y) / (flame_bottom - flame_top)
        # Width narrows toward tip
        base_hw = 8
        hw = max(1, int(base_hw * (1 - t * 0.85)))
        # Lean right slightly
        lean = int(t * 5)
        col = flame_col(t)
        for x in range(cx - hw + lean, cx + hw + 1 + lean):
            px(img, x, y, col)

    # Left wing flame — sweeps left
    for y in range(15, 48):
        t = (47 - y) / 32.0
        hw = max(1, int(6 * (1 - t * 0.8)))
        lean = -int(t * 12)
        col = flame_col(t * 0.9)
        x0 = cx - 8 + lean
        for x in range(x0, x0 + hw * 2):
            px(img, x, y, col)

    # Right wing flame — sweeps right
    for y in range(12, 48):
        t = (47 - y) / 35.0
        hw = max(1, int(7 * (1 - t * 0.8)))
        lean = int(t * 14)
        col = flame_col(t * 0.9)
        x0 = cx + 6 + lean - hw
        for x in range(x0, x0 + hw * 2):
            px(img, x, y, col)

    # Hot white core of main flame
    for y in range(flame_top, flame_bottom - 5):
        t = (flame_bottom - y) / (flame_bottom - flame_top)
        hw = max(0, int(3 * (1 - t * 0.9)))
        lean = int(t * 4)
        for x in range(cx - hw + lean, cx + hw + 1 + lean):
            if t > 0.7:
                px(img, x, y, WHITE_HOT)

    # Phoenix eye (bright ember near top of main flame)
    py_eye = 8
    px(img, cx + 3, py_eye, WHITE_HOT)
    px(img, cx + 4, py_eye, YELLOW_HOT)
    px(img, cx + 3, py_eye + 1, YELLOW_HOT)

    # Gold accent feather streaks
    for fy, fx_off in [(35, -14), (28, 18), (20, -18), (40, 16)]:
        px(img, cx + fx_off, fy, GOLD_FEATHER)
        px(img, cx + fx_off + 1, fy, GOLD_FEATHER)
        px(img, cx + fx_off, fy + 1, GOLD_BAND_L)

    flood_outline(img, BLACK)

    img.save(os.path.join(OUT_DIR, "hat_39.png"))
    print("Saved hat_39.png")


# ─────────────────────────────────────────────────────────────
# HAT 40 — Void Wraith Hood
# Full face-covering dark hood, deep purple/black, two glowing purple eye dots.
# Replaces head entirely (like a ghost costume).
# ─────────────────────────────────────────────────────────────
def draw_hat_40():
    img = new_img()

    HOOD_BLACK  = (15, 8, 28, 255)
    HOOD_DARK   = (30, 15, 55, 255)
    HOOD_MID    = (50, 25, 85, 255)
    HOOD_EDGE   = (70, 40, 110, 255)
    VOID_PURP   = (100, 50, 160, 255)
    EYE_GLOW_IN = (200, 100, 255, 255)
    EYE_GLOW_OUT= (140, 60, 200, 200)
    EYE_BRIGHT  = (230, 160, 255, 255)
    SHADOW_FACE = (20, 10, 38, 255)
    VOID_DARK   = (8, 4, 18, 255)

    cx = 33

    # ── Hood silhouette — full head replacement ───────────────
    # Occupies most of the 66x60 canvas
    # Rounded top, wider at bottom (drapes over shoulders)
    # Shape: top rounded dome y=2..20, body y=20..58 widening

    # Top dome (rounded)
    dome_top = 2
    dome_cx  = cx
    dome_ry  = 18  # half-height of dome
    dome_rx  = 22  # half-width at widest

    for y in range(dome_top, dome_top + dome_ry):
        t = (y - dome_top) / dome_ry
        hw = int(dome_rx * (t ** 0.5))
        for x in range(dome_cx - hw, dome_cx + hw + 1):
            # Gradient: darker in center, lighter on outer surface
            d_from_edge = min(x - (dome_cx - hw), (dome_cx + hw) - x)
            if d_from_edge <= 1:
                col = HOOD_EDGE
            elif d_from_edge <= 3:
                col = HOOD_MID
            else:
                col = HOOD_DARK
            px(img, x, y, col)

    # Body — trapezoid widening downward
    body_top  = dome_top + dome_ry - 1  # ~19
    body_bot  = 57
    for y in range(body_top, body_bot + 1):
        t = (y - body_top) / (body_bot - body_top)
        hw = int(21 + t * 10)  # 21 at top, 31 at bottom
        for x in range(cx - hw, cx + hw + 1):
            d_from_edge = min(x - (cx - hw), (cx + hw) - x)
            if d_from_edge == 0:
                col = BLACK
            elif d_from_edge <= 2:
                col = HOOD_EDGE
            elif d_from_edge <= 5:
                col = HOOD_MID
            else:
                # Interior face shadow area
                if y < body_top + 28:
                    # Face cavity area — darker
                    col = SHADOW_FACE
                else:
                    col = HOOD_DARK
            px(img, x, y, col)

    # Face cavity — darker recessed area in center
    face_x0, face_x1 = cx - 13, cx + 13
    face_y0, face_y1 = body_top + 2, body_top + 30
    for y in range(face_y0, face_y1):
        for x in range(face_x0, face_x1 + 1):
            d = min(x - face_x0, face_x1 - x, y - face_y0, face_y1 - y)
            if d <= 1:
                px(img, x, y, HOOD_MID)
            else:
                px(img, x, y, VOID_DARK)

    # Hood ridge / fold lines (subtle shading)
    for y in range(body_top, body_bot, 4):
        for x in range(cx - 5, cx + 6):
            d = img.getpixel((x, y))
            if d[3] > 0 and d != tuple(BLACK):
                px(img, x, y, HOOD_DARK)

    # Subtle highlight on top dome left edge (light catching)
    for y in range(dome_top + 2, dome_top + 12):
        t = (y - dome_top) / dome_ry
        hw = int(dome_rx * (t ** 0.5))
        hx = dome_cx - hw + 1
        if 0 <= hx < W:
            px(img, hx, y, VOID_PURP)

    # ── Two glowing eye dots ──────────────────────────────────
    eye_y   = face_y0 + 9
    eye_lx  = cx - 5
    eye_rx  = cx + 5

    def draw_eye_glow(ex, ey):
        # Outer glow halo
        for dx in range(-3, 4):
            for dy in range(-3, 4):
                dist = (dx*dx + dy*dy) ** 0.5
                if 2.2 < dist <= 3.2:
                    cur = img.getpixel((ex+dx, ey+dy)) if 0<=ex+dx<W and 0<=ey+dy<H else TRANS
                    if cur[3] > 0:
                        # blend glow onto hood
                        px(img, ex+dx, ey+dy, (
                            min(255, cur[0] + 40),
                            min(255, cur[1] + 10),
                            min(255, cur[2] + 60),
                            255
                        ))
        # Mid glow
        for dx, dy in [(-2,0),(2,0),(0,-2),(0,2),(-1,-1),(1,-1),(-1,1),(1,1),(-2,-1),(-2,1),(2,-1),(2,1),(-1,-2),(1,-2),(-1,2),(1,2)]:
            px(img, ex+dx, ey+dy, EYE_GLOW_OUT)
        # Inner glow
        for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
            px(img, ex+dx, ey+dy, EYE_GLOW_IN)
        # Bright center
        px(img, ex, ey, EYE_BRIGHT)

    draw_eye_glow(eye_lx, eye_y)
    draw_eye_glow(eye_rx, eye_y)

    # Hood void symbols (subtle rune-like marks lower body)
    for sx, sy in [(cx - 8, body_top + 38), (cx + 8, body_top + 38), (cx, body_top + 44)]:
        px(img, sx, sy, VOID_PURP)
        px(img, sx, sy-1, VOID_PURP)
        px(img, sx-1, sy, HOOD_MID)
        px(img, sx+1, sy, HOOD_MID)

    flood_outline(img, BLACK)

    img.save(os.path.join(OUT_DIR, "hat_40.png"))
    print("Saved hat_40.png")


# ─────────────────────────────────────────────────────────────
# HAT 41 — Gilded Jester
# Three-pronged jester hat, gold/purple/red, bells at tips, diamond band pattern.
# ─────────────────────────────────────────────────────────────
def draw_hat_41():
    img = new_img()

    GOLD_D   = (155, 105, 8, 255)
    GOLD_M   = (215, 165, 28, 255)
    GOLD_L   = (255, 215, 70, 255)
    PURP_D   = (70, 25, 110, 255)
    PURP_M   = (115, 50, 170, 255)
    PURP_L   = (165, 95, 225, 255)
    RED_D    = (155, 20, 20, 255)
    RED_M    = (210, 45, 35, 255)
    RED_L    = (255, 90, 70, 255)
    BELL_Y   = (245, 210, 45, 255)
    BELL_L   = (255, 238, 120, 255)
    BELL_D   = (155, 125, 8, 255)

    cx = 33

    # ── Hat skull-cap base ────────────────────────────────────
    # Rounded cap: y=38..54, x tapers from narrow top to wider brim
    cap_top = 38
    cap_bot = 54
    for y in range(cap_top, cap_bot + 1):
        t = (y - cap_top) / (cap_bot - cap_top)
        hw = int(10 + t * 16)  # 10 at top, 26 at brim
        for x in range(cx - hw, cx + hw + 1):
            d_edge = hw - abs(x - cx)
            # Alternating color stripes (diagonal diamond pattern)
            seg = ((x - cx + hw) // 4 + (y - cap_top) // 3) % 3
            if seg == 0:   base = PURP_M
            elif seg == 1: base = RED_M
            else:          base = GOLD_M
            # Highlight top-left
            if d_edge >= 3 and x < cx and y < cap_top + 8:
                if seg == 0:   base = PURP_L
                elif seg == 1: base = RED_L
                else:          base = GOLD_L
            px(img, x, y, base)

    # Cap outline
    for y in range(cap_top, cap_bot + 1):
        t = (y - cap_top) / (cap_bot - cap_top)
        hw = int(10 + t * 16)
        px(img, cx - hw, y, BLACK)
        px(img, cx + hw, y, BLACK)
    hline(img, cx - 10, cx + 10, cap_top, BLACK)
    hline(img, cx - 26, cx + 26, cap_bot, BLACK)

    # ── Gold band at cap top (where prongs emerge) ────────────
    band_y = cap_top + 1
    for x in range(cx - 11, cx + 12):
        px(img, x, band_y,     GOLD_L)
        px(img, x, band_y + 1, GOLD_M)
        px(img, x, band_y + 2, GOLD_D)

    # ── Decorative gold brim ──────────────────────────────────
    for y in range(cap_bot - 3, cap_bot + 1):
        t_b = (y - (cap_bot - 3)) / 3
        hw = int(26 - t_b * 2)
        for x in range(cx - hw, cx + hw + 1):
            px(img, x, y, GOLD_M if y < cap_bot else GOLD_D)
        if y == cap_bot - 2:
            hline(img, cx - hw, cx + hw, y, GOLD_L)
    hline(img, cx - 26, cx + 26, cap_bot, BLACK)
    hline(img, cx - 26, cx + 26, cap_bot - 3, BLACK)
    vline(img, cx - 26, cap_bot - 3, cap_bot, BLACK)
    vline(img, cx + 26, cap_bot - 3, cap_bot, BLACK)

    # ── Bezier helper ─────────────────────────────────────────
    def bezier(t, p0, p1, p2):
        return int((1-t)**2 * p0 + 2*(1-t)*t * p1 + t**2 * p2)

    # ── Three prongs (curved, drooping) ──────────────────────
    def draw_curved_prong(img, bx, by, ctrl_x, ctrl_y, tx, ty, main_c, dark_c, lite_c):
        steps = 40
        for i in range(steps + 1):
            t = i / steps
            px_ = bezier(t, bx, ctrl_x, tx)
            py_ = bezier(t, by, ctrl_y, ty)
            hw = max(2, int(4.5 * (1 - t * 0.7)))
            for dx in range(-hw, hw + 1):
                d_edge = hw - abs(dx)
                if d_edge == 0:
                    col = BLACK
                elif d_edge == 1:
                    col = dark_c
                elif dx < 0:
                    col = lite_c
                else:
                    col = main_c
                if 0 <= px_ + dx < W and 0 <= py_ < H:
                    img.putpixel((px_ + dx, py_), col)

    # Center prong: rises up, then curves left at tip — purple
    draw_curved_prong(img, cx,      cap_top, cx - 5, cap_top - 24, cx - 8, cap_top - 36,
                      PURP_M, PURP_D, PURP_L)
    # Left prong: sweeps left and droops down — red
    draw_curved_prong(img, cx - 8,  cap_top, cx - 22, cap_top - 18, cx - 30, cap_top - 8,
                      RED_M, RED_D, RED_L)
    # Right prong: sweeps right and droops down — gold
    draw_curved_prong(img, cx + 8,  cap_top, cx + 22, cap_top - 18, cx + 30, cap_top - 8,
                      GOLD_M, GOLD_D, GOLD_L)

    # ── Pom-pom bells at each tip ─────────────────────────────
    def draw_pompom(img, bx, by, col_main, col_lite, col_dark):
        # Round pom-pom, 7px diameter
        for dy in range(-3, 4):
            for dx in range(-3, 4):
                dist = (dx*dx + dy*dy) ** 0.5
                if dist <= 3.5:
                    if dist > 2.8:
                        col = BLACK
                    elif dist > 2.0:
                        col = col_dark
                    elif dx < 0 and dy < 0:
                        col = col_lite  # highlight
                    else:
                        col = col_main
                    if 0 <= bx + dx < W and 0 <= by + dy < H:
                        img.putpixel((bx + dx, by + dy), col)
        # Bright specular highlight
        if 0 <= bx - 1 < W and 0 <= by - 1 < H:
            img.putpixel((bx - 1, by - 1), (255, 255, 200, 255))

    # Center tip: y = cap_top - 36, x = cx - 8
    draw_pompom(img, cx - 8, cap_top - 36, PURP_M, PURP_L, PURP_D)
    # Left tip: y = cap_top - 8, x = cx - 30
    draw_pompom(img, cx - 30, cap_top - 8, RED_M, RED_L, RED_D)
    # Right tip: y = cap_top - 8, x = cx + 30
    draw_pompom(img, cx + 30, cap_top - 8, BELL_Y, BELL_L, BELL_D)

    # Tiny clapper lines below each pom-pom
    vline(img, cx - 8,  cap_top - 32, cap_top - 30, BLACK)
    vline(img, cx - 30, cap_top - 4,  cap_top - 2,  BLACK)
    vline(img, cx + 30, cap_top - 4,  cap_top - 2,  BLACK)

    # ── Gem dots on prongs ────────────────────────────────────
    for gx, gy, col in [
        (cx - 4, cap_top - 15, GOLD_L),
        (cx - 19, cap_top - 12, PURP_L),
        (cx + 19, cap_top - 12, RED_L),
    ]:
        px(img, gx, gy, col)
        px(img, gx, gy+1, col)

    flood_outline(img, BLACK)

    img.save(os.path.join(OUT_DIR, "hat_41.png"))
    print("Saved hat_41.png")


# ─────────────────────────────────────────────────────────────
# HAT 42 — Crimson War Mask
# Full red demon/oni face mask replacing head. Red face, gold horns,
# angry slanted eye holes (dark inside), grimace mouth, gold trim border.
# ─────────────────────────────────────────────────────────────
def draw_hat_42():
    img = new_img()

    MASK_DARK   = (140, 18, 10, 255)
    MASK_MID    = (200, 35, 20, 255)
    MASK_LITE   = (240, 70, 50, 255)
    MASK_HILIGHT= (255, 120, 95, 255)
    GOLD_D      = (150, 105, 5, 255)
    GOLD_M      = (210, 160, 22, 255)
    GOLD_L      = (255, 210, 60, 255)
    EYE_DARK    = (10, 5, 5, 255)
    EYE_GLOW    = (255, 60, 20, 255)
    TOOTH_W     = (240, 235, 220, 255)
    TOOTH_S     = (180, 175, 160, 255)
    HORN_D      = (130, 95, 0, 255)
    HORN_M      = (195, 148, 10, 255)
    HORN_L      = (250, 205, 50, 255)
    HORN_TIP    = (255, 230, 90, 255)
    BROW_SHADOW = (100, 10, 5, 255)

    cx = 33

    # ── Horns (drawn first, behind mask edges) ───────────────
    # Left horn: curves up-left from mask top edge
    # Right horn: curves up-right
    def draw_horn(img, base_x, base_y, tip_x, tip_y):
        steps = 20
        for i in range(steps + 1):
            t = i / steps
            # Bezier-ish: control point above
            ctrl_x = (base_x + tip_x) // 2
            ctrl_y = base_y - 18
            # Quadratic bezier
            bx = int((1-t)**2 * base_x + 2*(1-t)*t * ctrl_x + t**2 * tip_x)
            by = int((1-t)**2 * base_y + 2*(1-t)*t * ctrl_y + t**2 * tip_y)
            hw = max(1, int(4 * (1 - t * 0.85)))
            for dx in range(-hw, hw + 1):
                d_edge = hw - abs(dx)
                if d_edge == 0:
                    col = BLACK
                elif t > 0.75:
                    col = HORN_TIP
                elif t > 0.5:
                    col = HORN_L
                elif dx <= 0:
                    col = HORN_L
                else:
                    col = HORN_M
                px(img, bx + dx, by, col)

    draw_horn(img, cx - 12, 10, cx - 22, 2)
    draw_horn(img, cx + 12, 10, cx + 22, 2)

    # ── Mask face shape (oval, occupies most of canvas) ──────
    mask_cy = 34
    mask_rx = 24
    mask_ry = 26

    for y in range(mask_cy - mask_ry, mask_cy + mask_ry + 1):
        t_y = (y - mask_cy) / mask_ry
        hw = int(mask_rx * (1 - t_y**2) ** 0.5)
        if hw <= 0:
            continue
        for x in range(cx - hw, cx + hw + 1):
            # Distance from center for shading
            dx_n = (x - cx) / mask_rx
            dy_n = (y - mask_cy) / mask_ry
            dist = (dx_n**2 + dy_n**2) ** 0.5
            d_edge = hw - abs(x - cx)

            # Shading: bright in center-left (light source), dark edges
            if d_edge <= 1:
                col = MASK_DARK
            elif dist < 0.3:
                col = MASK_LITE
            elif dist < 0.6:
                col = MASK_MID
            else:
                col = MASK_DARK
            # Highlight on upper-left quadrant
            if x < cx and y < mask_cy and dist < 0.5:
                col = MASK_HILIGHT
            px(img, x, y, col)

    # ── Gold border trim around mask edge ─────────────────────
    for y in range(mask_cy - mask_ry, mask_cy + mask_ry + 1):
        t_y = (y - mask_cy) / mask_ry
        hw = int(mask_rx * (1 - t_y**2) ** 0.5)
        if hw <= 0:
            continue
        for border_x in [cx - hw, cx - hw + 1, cx + hw - 1, cx + hw]:
            cur = img.getpixel((border_x, y)) if 0 <= border_x < W else TRANS
            if cur[3] > 0:
                px(img, border_x, y, GOLD_M if abs(border_x - cx) == hw - 1 else GOLD_D)

    # ── Brow ridge (angry) ────────────────────────────────────
    # Heavy brow ridge above eyes, slants inward
    brow_y = mask_cy - 10
    for x in range(cx - 16, cx + 17):
        # Brow thickest at inner corners, slopes outward
        inner_dist = abs(x - cx)
        by_offset = 0 if inner_dist < 5 else int((inner_dist - 5) * 0.4)
        for dy in range(3):
            px(img, x, brow_y + by_offset + dy, BROW_SHADOW)
        # Gold brow edge
        px(img, x, brow_y + by_offset - 1, GOLD_D)

    # ── Eye sockets (dark angry slants) ───────────────────────
    # Left eye: slants down-left (inner corner high, outer low)
    # Right eye: mirror
    def draw_eye_socket(img, ex, ey, facing_right=True):
        # Parallelogram eye hole, 9 wide x 5 tall
        for dy in range(5):
            slant = dy if facing_right else -dy
            hw = 4
            for dx in range(-hw + slant, hw + slant + 1):
                if abs(dx - slant) <= hw:
                    px(img, ex + dx, ey + dy, EYE_DARK)
        # Glow rim inside socket
        for dx in range(-3, 4):
            px(img, ex + dx, ey, EYE_GLOW)
            px(img, ex + dx + (1 if facing_right else -1), ey + 4, EYE_GLOW)
        # Highlight (reflection)
        px(img, ex - 2 + (0 if facing_right else 4), ey + 1, (255, 180, 160, 255))

    draw_eye_socket(img, cx - 9, mask_cy - 8, facing_right=False)
    draw_eye_socket(img, cx + 9, mask_cy - 8, facing_right=True)

    # ── Nose ridge ────────────────────────────────────────────
    # Center nose bumps
    for dy in range(5):
        px(img, cx - 2, mask_cy + 2 + dy, MASK_DARK)
        px(img, cx + 2, mask_cy + 2 + dy, MASK_DARK)
        px(img, cx - 1, mask_cy + 3 + dy, MASK_LITE)
        px(img, cx + 1, mask_cy + 3 + dy, MASK_LITE)

    # ── Grimace mouth ─────────────────────────────────────────
    mouth_y = mask_cy + 10
    # Dark mouth interior
    for y in range(mouth_y, mouth_y + 6):
        hw = 9 - abs(y - mouth_y - 2)
        for x in range(cx - hw, cx + hw + 1):
            px(img, x, y, EYE_DARK)

    # Teeth (5 upper teeth)
    for i, tx in enumerate([cx - 8, cx - 4, cx, cx + 4, cx + 8]):
        for dy in range(4):
            if dy < 3:
                px(img, tx, mouth_y + dy, TOOTH_W)
                if tx - 1 >= 0: px(img, tx - 1, mouth_y + dy, TOOTH_S)
            else:
                px(img, tx, mouth_y + dy, TOOTH_S)

    # Mouth border
    hline(img, cx - 9, cx + 9, mouth_y - 1, GOLD_D)
    hline(img, cx - 9, cx + 9, mouth_y + 6, GOLD_D)

    # ── Chin detail ───────────────────────────────────────────
    chin_y = mask_cy + mask_ry - 5
    for x in range(cx - 8, cx + 9):
        px(img, x, chin_y, GOLD_D)
        px(img, x, chin_y + 1, GOLD_M)

    # ── Forehead kanji-like mark ──────────────────────────────
    fx, fy = cx, mask_cy - 17
    hline(img, fx - 3, fx + 3, fy, GOLD_L)
    vline(img, fx, fy, fy + 4, GOLD_L)
    hline(img, fx - 2, fx + 2, fy + 4, GOLD_M)

    flood_outline(img, BLACK)

    img.save(os.path.join(OUT_DIR, "hat_42.png"))
    print("Saved hat_42.png")


if __name__ == "__main__":
    draw_hat_38()
    draw_hat_39()
    draw_hat_40()
    draw_hat_41()
    draw_hat_42()
    print("All hats drawn.")
