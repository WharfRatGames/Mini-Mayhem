#!/usr/bin/env python3
"""Generate hat_37.png - BEN's Birthday Hat for Mini Mayhem"""

from PIL import Image, ImageDraw, ImageFont
import math, os

W, H = 66, 60

img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
d = ImageDraw.Draw(img)

# Color palette
GOLD       = (255, 215,   0, 255)
GOLD_DARK  = (180, 140,   0, 255)
GOLD_SHINE = (255, 240, 120, 255)
PURPLE     = (123,  47, 190, 255)
PURPLE_LT  = (170,  80, 230, 255)
PURPLE_DK  = ( 70,  20, 120, 255)
WHITE      = (255, 255, 255, 255)
RED        = (255,  50,  50, 255)
CYAN       = ( 50, 220, 255, 255)
GREEN      = ( 60, 220,  80, 255)
PINK       = (255, 100, 200, 255)
ORANGE     = (255, 150,  30, 255)
YELLOW     = (255, 240,  50, 255)
TEAL       = ( 30, 200, 170, 255)
OUTLINE    = ( 20,   8,  40, 255)

# Hat geometry: cone hat
# Tip at top-center, brim across bottom
# Canvas: 66 wide, 60 tall
# Brim: y=50..54, x=8..58
# Tip: x=33, y=2

TIP_X = 33
TIP_Y = 3
BRIM_Y = 48
LEFT_X = 7
RIGHT_X = 58

def hat_left_x(y):
    """Left edge of cone at row y"""
    t = (y - TIP_Y) / (BRIM_Y - TIP_Y)
    return TIP_X - t * (TIP_X - LEFT_X)

def hat_right_x(y):
    """Right edge of cone at row y"""
    t = (y - TIP_Y) / (BRIM_Y - TIP_Y)
    return TIP_X + t * (RIGHT_X - TIP_X)

# --- Draw cone base fill ---
# Alternate gold and purple vertical stripes
pixels = img.load()

for y in range(TIP_Y, BRIM_Y + 1):
    lx = int(math.ceil(hat_left_x(y)))
    rx = int(math.floor(hat_right_x(y)))
    for x in range(lx, rx + 1):
        # Stripe: divide hat into ~8 vertical bands based on x position
        # Normalize x within hat at this row
        width = rx - lx
        if width <= 0:
            col = GOLD
        else:
            norm = (x - lx) / width
            band = int(norm * 8)
            if band % 2 == 0:
                col = PURPLE
            else:
                col = GOLD
        pixels[x, y] = col

# --- Outline the cone edges ---
for y in range(TIP_Y, BRIM_Y + 1):
    lx = int(math.ceil(hat_left_x(y)))
    rx = int(math.floor(hat_right_x(y)))
    if 0 <= lx < W:
        pixels[lx, y] = OUTLINE
    if 0 <= rx < W:
        pixels[rx, y] = OUTLINE

# --- Gold diagonal band across hat (like a sash) ---
# Draw a diagonal gold stripe
for y in range(TIP_Y, BRIM_Y):
    lx = hat_left_x(y)
    rx = hat_right_x(y)
    width = rx - lx
    # Band centered at ~40% across, width ~12%
    for bw in range(-2, 3):
        bx = int(lx + width * 0.38 + bw)
        if lx <= bx <= rx:
            if pixels[bx, y] != OUTLINE:
                pixels[bx, y] = GOLD_SHINE if bw == 0 else GOLD

for y in range(TIP_Y, BRIM_Y):
    lx = hat_left_x(y)
    rx = hat_right_x(y)
    width = rx - lx
    for bw in range(-2, 3):
        bx = int(lx + width * 0.70 + bw)
        if lx <= bx <= rx:
            if pixels[bx, y] != OUTLINE:
                pixels[bx, y] = GOLD_SHINE if bw == 0 else GOLD

# --- Stars scattered on hat ---
def draw_star(cx, cy, size, color, outline=OUTLINE):
    """Draw a chunky pixel star"""
    # Simple 5-point star as pixel art
    pts = []
    for i in range(5):
        angle = math.radians(-90 + i * 72)
        pts.append((cx + math.cos(angle)*size, cy + math.sin(angle)*size))
        angle2 = math.radians(-90 + i * 72 + 36)
        pts.append((cx + math.cos(angle2)*(size*0.45), cy + math.sin(angle2)*(size*0.45)))
    d.polygon(pts, fill=color, outline=outline)

# Check if point is inside cone
def in_cone(x, y, margin=2):
    if y < TIP_Y + margin or y > BRIM_Y - margin:
        return False
    lx = hat_left_x(y) + margin
    rx = hat_right_x(y) - margin
    return lx <= x <= rx

# Stars on the hat
stars = [
    (22, 18, 4, YELLOW),
    (44, 22, 3, CYAN),
    (30, 35, 4, PINK),
    (17, 36, 3, GREEN),
    (48, 38, 3, ORANGE),
    (35, 14, 3, WHITE),
    (25, 44, 3, RED),
    (50, 14, 2, YELLOW),
]
for (sx, sy, ss, sc) in stars:
    if in_cone(sx, sy, 3):
        draw_star(sx, sy, ss, sc)

# --- Confetti dots ---
dots = [
    (19, 26, RED),
    (38, 29, CYAN),
    (28, 22, GREEN),
    (46, 31, PINK),
    (23, 40, ORANGE),
    (42, 42, YELLOW),
    (33, 42, CYAN),
    (16, 44, WHITE),
    (52, 25, GREEN),
    (15, 30, YELLOW),
    (53, 43, RED),
    (40, 11, PINK),
]
for (dx2, dy, dc) in dots:
    if in_cone(dx2, dy, 2):
        if 0 <= dx2 < W and 0 <= dy < H:
            pixels[dx2, dy] = dc
            if dx2+1 < W: pixels[dx2+1, dy] = dc
            if dy+1 < H:  pixels[dx2, dy+1] = dc
            if dx2+1 < W and dy+1 < H: pixels[dx2+1, dy+1] = dc

# --- Big gold star on tip ---
draw_star(TIP_X, TIP_Y - 1, 5, YELLOW, GOLD_DARK)
# Bright center
if 0 <= TIP_X < W and 0 <= TIP_Y-1 < H:
    pixels[TIP_X, TIP_Y-1] = WHITE

# --- Brim ---
BRIM_TOP = BRIM_Y
BRIM_BOT = BRIM_Y + 5
for y in range(BRIM_TOP, BRIM_BOT + 1):
    # Wider than cone
    brim_ext = (y - BRIM_TOP) * 0.3
    lx = max(0, int(LEFT_X - 3 - brim_ext))
    rx = min(W-1, int(RIGHT_X + 3 + brim_ext))
    for x in range(lx, rx+1):
        if y == BRIM_TOP or y == BRIM_BOT:
            pixels[x, y] = OUTLINE
        elif x == lx or x == rx:
            pixels[x, y] = OUTLINE
        else:
            # Gold/purple checkerboard brim
            if (x // 3 + y // 2) % 2 == 0:
                pixels[x, y] = GOLD
            else:
                pixels[x, y] = PURPLE_LT

# --- Streamers/ribbons hanging from brim ---
streamer_colors = [RED, CYAN, GREEN, PINK, ORANGE, YELLOW, WHITE]
# Hanging streamers as wavy lines below brim
streamer_starts = [11, 18, 26, 33, 40, 48, 56]
for i, sx in enumerate(streamer_starts):
    col = streamer_colors[i % len(streamer_colors)]
    col2 = streamer_colors[(i+2) % len(streamer_colors)]
    for seg in range(6):
        sy = BRIM_BOT + 1 + seg * 1
        # Wavy: alternate left/right
        wx = sx + (1 if seg % 2 == 0 else -1)
        wx = max(0, min(W-1, wx))
        if 0 <= sy < H:
            pixels[wx, sy] = col
            # Thickness
            if wx+1 < W:
                pixels[wx+1, sy] = col2 if seg % 3 == 0 else col

# --- Gold shine on left edge of hat ---
for y in range(TIP_Y + 2, BRIM_Y - 2):
    lx = int(math.ceil(hat_left_x(y))) + 1
    if 0 <= lx < W and pixels[lx, y] != OUTLINE:
        pixels[lx, y] = GOLD_SHINE

# --- Save ---
out_path = "/home/dusty/arty/deploy/assets/cosmetics/hat_37.png"
img.save(out_path)
print(f"Saved {out_path}")

# --- Preview: 4x scale, dark background, label ---
PREV_W, PREV_H_IMG = 264, 240
bg_color = (13, 15, 26, 255)
label_h = 30
preview = Image.new("RGBA", (PREV_W, PREV_H_IMG + label_h), bg_color)

# Scale up 4x
hat_scaled = img.resize((W*4, H*4), Image.NEAREST)
# Center in 264x240
ox = (PREV_W - W*4) // 2
oy = (PREV_H_IMG - H*4) // 2
preview.paste(hat_scaled, (ox, oy), hat_scaled)

# Label
pd = ImageDraw.Draw(preview)
label = "BEN'S BIRTHDAY HAT"
# Try to use a font, fallback to default
try:
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18)
except:
    font = ImageFont.load_default()

bbox = pd.textbbox((0, 0), label, font=font)
tw = bbox[2] - bbox[0]
tx = (PREV_W - tw) // 2
ty = PREV_H_IMG + 4
# Shadow
pd.text((tx+1, ty+1), label, font=font, fill=(0,0,0,200))
# Gold text
pd.text((tx, ty), label, font=font, fill=GOLD)

prev_path = "/home/dusty/arty/assets/ben_birthday_hat_preview.png"
preview.save(prev_path)
print(f"Saved {prev_path}")
